# Bảng đối chiếu số liệu – artifact OPC UA

Trạng thái: đã đối chiếu bằng `tools/opcua_verify_artifacts.py`; báo cáo máy đọc
được nằm tại `experiments/opcua_research_v2/scientific_verification.json`.

| Nội dung dự kiến dùng trong đồ án | Số liệu/khẳng định | Artifact trực tiếp | Mã nguồn tạo/kiểm tra | Kết luận được phép và lưu ý |
| --- | --- | --- | --- | --- |
| Quy mô tập phát triển | 3.427 cửa sổ 5 giây | `label_audit/summary.json`; `label_audit/label_manifest.csv` | `tools/opcua_label_manifest.py`; `tools/opcua_verify_artifacts.py` | Đã xác minh số hàng và khóa cửa sổ duy nhất. |
| Phân bố trước activity-aware | 2.680 BENIGN, 747 attack | `label_audit/summary.json` | `tools/opcua_label_manifest.py:168-176` | Đây là checkpoint trước hiệu chỉnh, không phải tập cuối dùng cho model đã lưu. |
| Hiệu chỉnh nhãn | 29 cửa sổ: 24 SESSION_BURST, 4 SUBSCRIPTION_FLOOD, 1 PROTOCOL_FUZZ | `label_audit/changed_windows.csv`; `label_audit/summary.json` | `extract_opcua_features_ext.py:169-170,370-380`; `tools/opcua_label_manifest.py:112,171` | Nhất quán với quy tắc activity-aware; chưa tái kiểm trực tiếp từ PCAP vì CSV không lưu số gói attacker. |
| Phân bố sau activity-aware | 2.709 BENIGN, 718 attack | `label_audit/summary.json` | `tools/opcua_verify_artifacts.py` | Tổng vẫn 3.427. |
| Không gian đặc trưng | 61 đầy đủ; 50 sau khi loại 11; 24 service-only | `feature_ablation/feature_groups.json` | `tools/opcua_feature_ablation.py:30-75,268-289` | 11 trường là aggregate cấu trúc nguồn, không phải IP thô. |
| Cấu hình model ablation | ExtraTrees, 400 cây, max_depth=10, seed 0, không class_weight | `feature_ablation/run_config.json` | `tools/opcua_feature_ablation.py:207-214,397-412` | Khớp recipe model gốc ở tham số cốt lõi. |
| Full-61 Group-CV mới | Macro-F1 0,961831 | `feature_ablation/ablation_results.csv`; `classification_all_61_train_group_cv.json` | `tools/opcua_feature_ablation.py:311-335` | So sánh nội bộ runtime 1.9.1; không thay thế metadata 1.8.0. |
| Metadata Group-CV model gốc | Macro-F1 0,959851 | `model_opcua/meta.json` | `train_opcua_eval.py:61-89` | Có thể trích dẫn như kết quả gốc; chưa tái lập bit-for-bit. |
| OOD2 full-61 | TP/FP/TN/FN = 124/23/457/1; attack precision 0,8435; recall 0,992; F1 0,9118; FPR 0,0479; multiclass Macro-F1 0,517804 | `feature_ablation/ablation_results.csv`; `warmup_ood/ood2_predictions.csv`; `eval_ood2_extratrees/ood_report.json` | `tools/opcua_export_predictions.py`; `tools/opcua_verify_artifacts.py:173-184,204-230` | Tái lập đúng inference legacy. OOD2 đã tham gia chọn ExtraTrees nên không phải final test độc lập. |
| Binary Macro-F1 OOD2 trong đồ án | 0,943 | `eval_ood2_extratrees/ood_report.json`; confusion 124/23/457/1 | `evaluate_opcua_ood.py` | Không mâu thuẫn với attack-class F1 0,9118; hai cách lấy trung bình khác nhau. |
| Warm-up OOD2 | 36 cửa sổ, 23 FP; 444 steady, 0 FP | `warmup_ood/error_summary.json`; `warmup_ood/ood2_predictions.csv` | `tools/opcua_warmup_error_analysis.py`; `tools/opcua_verify_artifacts.py` | Chỉ chứng minh lỗi tập trung ở warm-up của OOD2. |
| Episode OOD2 | 86 ID không trộn nhãn; 17 dương, 69 âm; TP/FP/TN/FN = 17/23/46/0 | `warmup_ood/ood2_episode_summary.json`; hai CSV episode | `tools/opcua_episode_eval.py:33,198-230`; `tools/opcua_verify_artifacts.py:233-290` | Recall 1,000 nhưng precision 0,425 và FPR episode 0,3333. |
| Episode theo pha | steady 0/37 FP; warm-up/cooldown 23/32 FP | `warmup_ood/ood2_episode_summary.json`; `warmup_ood/ood2_negative_episode_results.csv` | `tools/opcua_episode_eval.py` | FPR episode warm-up 0,71875; không được chỉ báo 17/17 mà bỏ precision. |
| Ablation bỏ 11 trường | CV Macro-F1 0,953913; OOD2 Macro-F1 0,408665; attack F1 0,627027; FPR 0,268750; testclean Macro-F1 0,940504 | `feature_ablation/ablation_results.csv` | `tools/opcua_feature_ablation.py` | Chứng minh feature dependence trong thiết kế hiện tại, không chứng minh leakage. |
| Service-only | CV Macro-F1 0,891816; OOD2 recall 0,440; attack F1 0,550; FPR 0,041667 | `feature_ablation/ablation_results.csv` | `tools/opcua_feature_ablation.py` | FPR thấp đi kèm bỏ sót 70/125 cửa sổ; không diễn giải thành cải thiện tổng thể. |
| Baseline ngưỡng | OOD2 recall 0,952; attack F1 0,670423; 111 FP; FPR 0,231250 | `feature_ablation/ablation_results.csv`; `simple_baseline_thresholds.json` | `tools/opcua_feature_ablation.py:217-249,367-390` | Model học máy không được giải thích chỉ bởi một luật ngưỡng đơn giản. |
| Testclean full-61 | TP/FP/TN/FN = 45/0/708/0; Macro-F1 0,949340 | `feature_ablation/ablation_results.csv`; `eval_testclean_extratrees/ood_report.json` | `tools/opcua_verify_artifacts.py:185-199` | Tái lập inference legacy; tập có ít attack và không có warm-up. |
| Vai trò OOD2 | Dùng trực tiếp để chấm nhiều thuật toán và chọn ExtraTrees | `scratch_try_improve_opcua_ood.py:34-36,42-91`; `train_opcua_eval.py:13-20` | Mã nguồn gốc | Phải gọi là development/cross-session validation, không gọi là untouched final test. |
| Phiên bản model | model lưu: sklearn 1.8.0; model ablation: 1.9.1 | marker trong hai file `classifier.joblib`; `scientific_verification.json` | `tools/opcua_verify_artifacts.py:293-303` | Tái lập được inference; chưa xác định duy nhất nguyên nhân lệch CV 0,001980. |
| Kiểm chứng tổng thể | 24/24 phép kiểm tra pass | `scientific_verification.json` | `tools/opcua_verify_artifacts.py` | Chứng minh tính nhất quán nội bộ của artifact, không tạo thêm tính độc lập thống kê. |

## Các số liệu chưa nên đưa vào như kết luận xác nhận

- Không gọi OOD2 là tập kiểm định cuối độc lập hoặc “unseen” đối với quyết định
  mô hình.
- Không khẳng định đã loại bỏ data leakage sau ablation 11 đặc trưng.
- Không dùng 17/17 episode mà không kèm 23 false-positive episode và precision
  0,425.
- Không gọi điểm Group-CV 0,961831 là tái lập chính xác metadata 0,959851.
- Không suy rộng 0 FP trên 444 cửa sổ steady thành FPR bằng 0 trong vận hành OPC
  UA nói chung.
