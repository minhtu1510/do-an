# Bản thảo bổ sung nhánh OPC UA

Trạng thái: bản để duyệt, chưa chèn vào `bao-cao/Thao_Tu_OTSecurity_vf.docx`.
Các số thứ tự bảng dưới đây dùng ký hiệu `xx` để tránh xung đột với hệ thống
đánh số hiện tại của đồ án.

## Nội dung đề xuất bổ sung vào Mục 3.10

### 3.10.5. Kiểm toán nhãn theo hoạt động quan sát được

**Câu hỏi nghiên cứu.** Việc gán nhãn chỉ theo khoảng thời gian của episode có
làm xuất hiện các cửa sổ mang nhãn tấn công mặc dù lưu lượng của máy kiểm thử đã
kết thúc hay không, và nếu có thì mức hiệu chỉnh có thể được truy vết tới từng
cửa sổ hay không?

**Phương pháp thực nghiệm.** Hai bảng đặc trưng được đối chiếu theo khóa
`window_start_ms` và `window_end_ms`: bảng gán nhãn theo khoảng thời gian
`opcua_harvest_ext.csv` và bảng activity-aware
`opcua_harvest_ext_aa.csv`. Trong bộ trích xuất, một cửa sổ giao với episode chỉ
giữ nhãn tấn công khi cửa sổ đó có ít nhất một gói mang địa chỉ của máy tấn
công; nếu không, cửa sổ được trả về BENIGN. Kiểm toán cuối không thay đổi đặc
trưng, mà lập manifest cho toàn bộ cửa sổ, so sánh nhãn trước–sau và lưu riêng
danh sách cửa sổ thay đổi.

**Điều kiện đánh giá.** Phép đối chiếu được thực hiện trên 3.427 cửa sổ 5 giây
của capture phát triển. Hai bảng có cùng tập khóa cửa sổ và không có khóa trùng.
Địa chỉ máy tấn công chỉ được dùng trong giai đoạn trích xuất để tạo biến
`has_attacker`; địa chỉ này, `episode_id`, `scenario_id` và các trường metadata
không được đưa vào vector học máy. CSV đặc trưng không lưu số gói của máy tấn
công trong từng cửa sổ, vì vậy vòng kiểm toán hiện tại kiểm tra được sự thay đổi
nhãn và các bộ đếm giao thức, nhưng không tự tái dựng bằng chứng gói tin từ PCAP.

**Kết quả thực tế.** Có 29/3.427 cửa sổ đổi từ nhãn tấn công sang BENIGN, gồm 24
cửa sổ SESSION_BURST, 4 cửa sổ SUBSCRIPTION_FLOOD và 1 cửa sổ PROTOCOL_FUZZ.
Số cửa sổ BENIGN tăng từ 2.680 lên 2.709; số cửa sổ tấn công giảm từ 747 xuống
718; tổng số cửa sổ không đổi. Các lớp còn lại không thay đổi số lượng.

**Bảng 3.xx. Kiểm toán nhãn trước và sau activity-aware labeling**

| Nhãn/nhóm | Trước hiệu chỉnh | Sau hiệu chỉnh | Chênh lệch |
| --- | ---: | ---: | ---: |
| BENIGN | 2.680 | 2.709 | +29 |
| SESSION_BURST | 53 | 29 | -24 |
| SUBSCRIPTION_FLOOD | 70 | 66 | -4 |
| PROTOCOL_FUZZ | 28 | 27 | -1 |
| Toàn bộ lớp tấn công | 747 | 718 | -29 |
| Tổng số cửa sổ | 3.427 | 3.427 | 0 |

**Nhận xét được bằng chứng hỗ trợ.** Kết quả xác nhận nhiễu nhãn tập trung ở
đuôi của ba loại episode, thay vì phân bố trên toàn bộ 11 kịch bản. Đóng góp của
bước này là tăng khả năng truy vết ground truth: từng thay đổi đều có khóa thời
gian, nhãn cũ, nhãn mới, episode và các bộ đếm OPC UA đi kèm. Kết quả không nên
được diễn giải thành bằng chứng rằng toàn bộ nhãn sau hiệu chỉnh đều đúng tuyệt
đối; nó chỉ chứng minh rằng 29 thay đổi trong manifest nhất quán với quy tắc
activity-aware đã cài đặt.

**Hạn chế của kết luận.** Do `attacker_packet_count` không được lưu trong bảng
đặc trưng, kiểm toán CSV chưa phải một phép xác minh độc lập lại từ PCAP. Quy tắc
cũng giả định địa chỉ máy kiểm thử đã biết và không xử lý trường hợp tấn công qua
client trung gian hoặc địa chỉ thay đổi. Nghiên cứu tiếp theo cần lưu số gói và
bằng chứng packet-level cho mỗi cửa sổ, sau đó kiểm tra ngẫu nhiên trực tiếp trên
PCAP.

**Artifact nguồn cần gắn với bảng:**

- `experiments/opcua_research_v2/label_audit/summary.json`;
- `experiments/opcua_research_v2/label_audit/label_manifest.csv`;
- `experiments/opcua_research_v2/label_audit/changed_windows.csv`;
- quy tắc activity-aware tại `extract_opcua_features_ext.py`, dòng 169–170 và
  370–380;
- trình kiểm toán tại `tools/opcua_label_manifest.py`.

## Nội dung đề xuất bổ sung vào Mục 5.10

### 5.10.7. Kiểm chứng độ phụ thuộc vào nhóm đặc trưng cấu trúc nguồn

**Câu hỏi nghiên cứu.** Hiệu năng của bộ phát hiện OPC UA phụ thuộc ở mức nào
vào 11 đặc trưng mô tả số lượng, mức tập trung và giá trị cực đại theo nguồn
client; các đặc trưng này có đủ để kết luận rằng mô hình bị rò rỉ dữ liệu hay
không?

**Phương pháp thực nghiệm.** ExtraTrees được giữ cố định ở 400 cây, độ sâu tối
đa 10, `random_state=0` và không dùng `class_weight`. Nhãn WRITE_DENIED và
INVALID_WRITE được gộp thành MALICIOUS_WRITE như pipeline gốc. Bốn cấu hình
được so sánh: toàn bộ 61 đặc trưng; 50 đặc trưng sau khi loại đúng 11 trường cấu
trúc nguồn; 24 bộ đếm dịch vụ/trạng thái OPC UA; và baseline luật ngưỡng trên 11
đặc trưng, với ngưỡng phân vị 0,99 ước lượng chỉ từ cửa sổ BENIGN của tập phát
triển. Ba cấu hình ExtraTrees được đánh giá bằng GroupKFold 5-fold theo
`episode_id`, sau đó fit trên toàn bộ tập phát triển và áp dụng lên OOD2 và
testclean.

Mười một trường được chia thành ba nhóm chức năng: (i) số lượng nguồn, đích và
client (`unique_src_ip_count`, `unique_dst_ip_count`, `client_src_count`); (ii)
mức tập trung lưu lượng theo client (`max_pkts_by_client`,
`max_bytes_by_client`, `max_services_by_client`, `busiest_client_pkt_frac`);
và (iii) cực đại dịch vụ theo một nguồn (`max_opn_by_single_src`,
`max_read_by_single_src`, `max_create_session_by_single_src`,
`max_browse_by_single_src`). Tất cả đều là số đếm, cực đại hoặc tỷ lệ; không
trường nào lưu giá trị địa chỉ nguồn cụ thể.

**Điều kiện đánh giá.** Mọi cấu hình trong bảng ablation được chạy trong cùng
môi trường scikit-learn 1.9.1 và cùng dữ liệu, nên chênh lệch tương đối giữa các
cấu hình có thể so sánh nội bộ. OOD2 đã được dùng trước đó để so sánh thuật toán
và lựa chọn ExtraTrees; do đó, các chỉ số OOD2 dưới đây là kết quả phát triển và
phân tích sức bền giữa phiên, không phải ước lượng kiểm định cuối trên tập chưa
từng được quan sát.

**Bảng 5.xx. Ablation nhóm đặc trưng OPC UA**

| Cấu hình | Số đặc trưng | Group-CV Macro-F1 | OOD2 Macro-F1 đa lớp | OOD2 precision tấn công | OOD2 recall tấn công | OOD2 F1 tấn công | OOD2 FPR | Testclean Macro-F1 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Toàn bộ | 61 | 0,961831 | 0,517804 | 0,843537 | 0,992 | 0,911765 | 0,047917 | 0,949340 |
| Loại 11 trường cấu trúc nguồn | 50 | 0,953913 | 0,408665 | 0,473469 | 0,928 | 0,627027 | 0,268750 | 0,940504 |
| Chỉ dịch vụ/trạng thái OPC UA | 24 | 0,891816 | 0,429433 | 0,733333 | 0,440 | 0,550000 | 0,041667 | 0,924602 |
| Baseline ngưỡng giao thức | 11 | – | – | 0,517391 | 0,952 | 0,670423 | 0,231250 | – |

**Kết quả thực tế.** Khi loại 11 trường cấu trúc nguồn, Macro-F1 Group-CV chỉ
giảm từ 0,961831 xuống 0,953913 và Macro-F1 testclean giảm từ 0,949340 xuống
0,940504. Tuy nhiên, trên OOD2, số cảnh báo giả tăng từ 23 lên 129, FPR tăng từ
0,047917 lên 0,268750, còn F1 của lớp tấn công giảm từ 0,911765 xuống 0,627027.
Cấu hình chỉ dùng dịch vụ/trạng thái giữ FPR OOD2 ở 0,041667 nhưng chỉ phát hiện
55/125 cửa sổ tấn công. Baseline ngưỡng đạt recall 0,952 nhưng tạo 111 cảnh báo
giả trên OOD2.

**Nhận xét được bằng chứng hỗ trợ.** Mười một trường bị loại không chứa địa chỉ
IP thô; chúng là số lượng nguồn/đích, số client, tỷ lệ lưu lượng của client bận
nhất và các giá trị cực đại theo nguồn. Kết quả chỉ chứng minh rằng mô hình phụ
thuộc vào thông tin cấu trúc và mức tập trung lưu lượng để hiệu chỉnh quyết định
trên OOD2. Việc loại chúng làm kết quả OOD2 xấu đi, đặc biệt do cảnh báo giả,
nhưng hiện tượng này không chứng minh rò rỉ metadata hay nhận dạng trực tiếp máy
tấn công. Đồng thời, nó cũng chưa chứng minh đã loại bỏ mọi dạng data leakage:
thiết kế hiện tại chưa thay đổi topology, số client, địa chỉ nguồn hoặc công cụ
sinh traffic một cách độc lập giữa train và test.

**Hạn chế của kết luận.** Tên cấu hình `no_client_identity_proxy` trong artifact
chỉ là nhãn kỹ thuật; về bản chất đây là phép loại nhóm đặc trưng cấu trúc nguồn,
không phải phép xóa định danh vì mô hình vốn không nhận IP thô. Để kiểm định
leakage cần một thiết kế riêng, chẳng hạn giữ nguyên hành vi nhưng hoán đổi địa
chỉ/client, tách train–test theo host hoặc topology, và thu thêm phiên với client
benign khác. OOD2 cũng đã tham gia lựa chọn model nên không thể dùng chính mức
suy giảm này làm bằng chứng xác nhận cuối cùng.

**Artifact nguồn cần gắn với bảng:**

- `experiments/opcua_research_v2/feature_ablation/ablation_results.csv`;
- `experiments/opcua_research_v2/feature_ablation/feature_groups.json`;
- `experiments/opcua_research_v2/feature_ablation/run_config.json`;
- các confusion matrix và classification report cùng thư mục;
- mã tạo kết quả tại `tools/opcua_feature_ablation.py`.

### 5.10.8. Đánh giá theo cửa sổ, episode và trạng thái phiên

**Câu hỏi nghiên cứu.** Recall cao ở cấp cửa sổ có chuyển thành khả năng phát
hiện đầy đủ các episode hay không, và chi phí cảnh báo giả ở cấp episode là bao
nhiêu khi tách benign ổn định khỏi warm-up/cooldown?

**Phương pháp thực nghiệm.** Model ExtraTrees đã lưu được áp dụng lên 605 cửa
sổ OOD2. Ở cấp cửa sổ, nhãn dự đoán được quy về BENIGN/tấn công. Ở cấp episode,
mỗi `episode_id` được coi là dương nếu chứa cửa sổ tấn công và được phát hiện khi
ít nhất một cửa sổ có tổng xác suất các lớp không-BENIGN
`pred_attack_score >= 0,5`. OOD2 có 86 `episode_id`; không có ID nào trộn cửa
sổ benign và tấn công. Vì vậy có thể lập ma trận 17 episode dương và 69
episode/chunk benign âm.

**Điều kiện đánh giá.** Ngưỡng 0,5 và quy tắc “ít nhất một cửa sổ” được dùng cho
phân tích này. Trên toàn bộ 605 cửa sổ, quyết định theo ngưỡng
`pred_attack_score` trùng với quyết định nhị phân suy ra từ lớp argmax. Các đơn
vị âm gồm 37 chunk polling ổn định và 32 episode warm-up/cooldown; vì vậy
precision episode phụ thuộc trực tiếp vào cách timeline chia các đoạn benign.

**Bảng 5.xx. Đối chiếu kết quả cấp cửa sổ và cấp episode trên OOD2**

| Đơn vị đánh giá | Dương thực | Âm thực | TP | FP | TN | FN | Precision | Recall | FPR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Cửa sổ 5 giây | 125 | 480 | 124 | 23 | 457 | 1 | 0,8435 | 0,9920 | 0,0479 |
| `episode_id` / benign chunk | 17 | 69 | 17 | 23 | 46 | 0 | 0,4250 | 1,0000 | 0,3333 |

**Bảng 5.xx. Cảnh báo giả episode theo trạng thái benign**

| Trạng thái benign | Số episode/chunk | False-positive episode | FPR episode |
| --- | ---: | ---: | ---: |
| Polling ổn định | 37 | 0 | 0,0000 |
| Warm-up/cooldown | 32 | 23 | 0,7188 |
| Tổng | 69 | 23 | 0,3333 |

**Kết quả thực tế.** Ở cấp cửa sổ, model đạt TP/FP/TN/FN = 124/23/457/1.
F1 của lớp tấn công là 0,9118; Macro-F1 nhị phân đang trình bày trong Bảng 5.16
là 0,943, hai giá trị khác nhau do cách lấy trung bình nhưng xuất phát từ cùng
một ma trận nhầm lẫn. Ở cấp episode, cả 17 episode tấn công đều có ít nhất một
cửa sổ vượt ngưỡng, nhưng có thêm 23 false-positive episode/chunk benign, làm
precision episode chỉ còn 0,425. Toàn bộ 23 false-positive episode nằm trong
warm-up/cooldown; 37 chunk polling ổn định không có cảnh báo giả.

**Nhận xét được bằng chứng hỗ trợ.** Kết quả 17/17 chỉ chứng minh recall episode
trên OOD2 theo quy tắc đã nêu; nó không đủ để kết luận hệ thống có hiệu quả vận
hành cao nếu bỏ qua precision 0,425. Phân tích đồng thời hai mức cho thấy mô
hình hiếm khi bỏ sót toàn bộ một episode tấn công, nhưng traffic thiết lập phiên
tạo số lượng cảnh báo giả đáng kể. Đây là bằng chứng trực tiếp cho nhu cầu mô
hình hóa trạng thái phiên hoặc cơ chế gom cảnh báo có khả năng nhận diện warm-up
mà không dùng ground truth.

**Hạn chế của kết luận.** OOD2 đã tham gia quá trình chọn thuật toán và ngưỡng
episode chưa được đánh giá trên một capture frozen mới. Mỗi `episode_id` benign
phản ánh cách chia timeline hiện tại, không nhất thiết tương ứng một sự kiện vận
hành độc lập trong mọi hệ thống. Do đó precision 0,425 là đặc tính của giao thức
đánh giá hiện tại, không phải ước lượng phổ quát cho triển khai thực tế.

**Artifact nguồn cần gắn với bảng:**

- `experiments/opcua_research_v2/warmup_ood/ood2_predictions.csv`;
- `experiments/opcua_research_v2/warmup_ood/error_summary.json`;
- `experiments/opcua_research_v2/warmup_ood/ood2_episode_summary.json`;
- `experiments/opcua_research_v2/warmup_ood/ood2_episode_results.csv`;
- `experiments/opcua_research_v2/warmup_ood/ood2_negative_episode_results.csv`;
- mã tại `tools/opcua_export_predictions.py`,
  `tools/opcua_warmup_error_analysis.py` và `tools/opcua_episode_eval.py`.

### 5.10.9. Vai trò của OOD2 và phạm vi tái lập

**Câu hỏi nghiên cứu.** Những kết quả nào có thể tuyên bố là tái lập từ artifact
hiện có, và OOD2 giữ vai trò gì trong quy trình phát triển mô hình?

**Phương pháp thực nghiệm.** Lịch sử mã nguồn được đối chiếu với metadata model,
báo cáo legacy và artifact vòng kiểm chứng. Script
`scratch_try_improve_opcua_ood.py` huấn luyện nhiều thuật toán trên tập phát
triển, chấm trực tiếp trên OOD2 và chọn cấu hình có Macro-F1 OOD2 cao nhất.
`train_opcua_eval.py` sau đó ghi rõ ExtraTrees được chọn từ phép ablation
cross-session này. Model đã lưu được nạp lại để xuất dự đoán từng cửa sổ và so
sánh với báo cáo OOD2/testclean cũ. Một model cùng tham số cũng được huấn luyện
lại trong môi trường mới để kiểm tra Group-CV.

**Điều kiện đánh giá.** Model đã lưu mang marker scikit-learn 1.8.0; các model
ablation mới mang marker 1.9.1. Cả hai dùng 61 đặc trưng theo cùng thứ tự, cùng
phép gộp nhãn và cùng cấu hình ExtraTrees cốt lõi. Tuy nhiên, chưa có lần huấn
luyện lại model trong đúng môi trường 1.8.0 từ đầu đến cuối.

**Kết quả thực tế.** Suy luận bằng model đã lưu tái tạo đúng ma trận OOD2
124/23/457/1, Macro-F1 đa lớp 0,517804 và kết quả testclean 45/0/708/0 với
Macro-F1 0,949340; các giá trị này khớp báo cáo legacy trong giới hạn làm tròn.
Ngược lại, Group-CV khi huấn luyện mới bằng scikit-learn 1.9.1 đạt 0,961831,
trong khi metadata model 1.8.0 ghi 0,959851.

**Nhận xét được bằng chứng hỗ trợ.** Có thể tuyên bố đã tái lập kết quả suy luận
của model đã lưu trên OOD2 và testclean, cũng như tái lập logic tính metric và
thứ tự đặc trưng. Chưa thể tuyên bố tái lập bit-for-bit quá trình huấn luyện hay
điểm Group-CV. Chênh lệch phiên bản thư viện là một nguyên nhân khả dĩ cho sai
khác 0,001980, nhưng chưa được chứng minh là nguyên nhân duy nhất vì chưa chạy
đối chứng hai phiên bản trên cùng môi trường khóa.

**Hạn chế của kết luận.** OOD2 độc lập theo thời gian thu so với tập phát triển
nhưng không độc lập về quyết định mô hình: nó đã được dùng để chọn ExtraTrees.
Vì vậy OOD2 hỗ trợ phân tích cross-session và lỗi warm-up, không cung cấp một
ước lượng kiểm định cuối không thiên lệch. Một kết luận xác nhận cần khóa code,
feature schema, model, phiên bản thư viện và ngưỡng trước khi thu capture mới.

**Artifact nguồn cần gắn với nội dung:**

- `scratch_try_improve_opcua_ood.py`, đặc biệt dòng 34–36, 42–90;
- `train_opcua_eval.py`, đặc biệt dòng 13–20 và 61–89;
- `model_opcua/meta.json` và `model_opcua/classifier.joblib`;
- `eval_ood2_extratrees/ood_report.json`;
- `eval_testclean_extratrees/ood_report.json`;
- `experiments/opcua_research_v2/scientific_verification.json`.

## Nội dung đề xuất bổ sung vào Mục 5.12

### 5.12.x. Giới hạn hiệu lực của kiểm chứng khoa học OPC UA

**Câu hỏi nghiên cứu.** Sau vòng kiểm toán nhãn, ablation đặc trưng, phân tích
warm-up và đánh giá episode, phạm vi kết luận nào còn được bằng chứng hiện có hỗ
trợ và những khẳng định nào phải để lại cho một thí nghiệm xác nhận mới?

**Phương pháp thực nghiệm.** Toàn bộ con số dự kiến đưa vào đồ án được truy vết
từ bảng tổng hợp về dự đoán từng cửa sổ, confusion matrix, manifest nhãn, mã
nguồn tạo artifact và metadata model. Trình kiểm chứng tự động tính lại 24 quan
hệ nhất quán, gồm tổng hàng, phân bố nhãn, metric từ TP/FP/TN/FN, Macro-F1 từ
classification report, sự tương ứng giữa confusion matrix và bảng ablation,
ma trận episode và marker phiên bản model.

**Điều kiện đánh giá.** Kiểm chứng này dùng lại dữ liệu đã tồn tại và không thu
capture mới. Vì vậy nó đánh giá tính nhất quán và khả năng truy vết của bằng
chứng, không làm tăng mức độc lập thống kê của OOD2 hoặc testclean.

**Kết quả thực tế.** Cả 24 kiểm tra đều đạt. Các số liệu label audit, ablation,
warm-up, OOD2 và episode có artifact hỗ trợ và có thể tính lại. Tuy nhiên, bốn
giới hạn vẫn tồn tại: OOD2 đã tham gia chọn mô hình; 11 đặc trưng bị loại chỉ
chứng minh feature dependence chứ không chứng minh hoặc loại trừ data leakage;
episode recall 1,000 đi kèm precision 0,425; và Group-CV mới không tái lập chính
xác metadata do khác phiên bản scikit-learn.

**Bảng 5.xx. Ranh giới của các kết luận OPC UA sau kiểm chứng**

| Kết luận | Mức bằng chứng hiện có | Cách diễn giải được phép | Không nên khẳng định |
| --- | --- | --- | --- |
| Hiệu chỉnh 29 cửa sổ | Manifest đầy đủ và quy tắc code | 29 thay đổi nhất quán với activity-aware labeling | Toàn bộ ground truth đã được xác minh độc lập từ PCAP |
| Vai trò 11 đặc trưng cấu trúc nguồn | Ablation cùng runtime | Model phụ thuộc mạnh vào nhóm này trên OOD2 | Đã phát hiện hoặc loại bỏ data leakage |
| OOD2 124/125 cửa sổ tấn công | Dự đoán từng hàng và confusion matrix | Quan sát cross-session của model đã chọn | Hiệu năng cuối không thiên lệch trên dữ liệu chưa dùng |
| Episode 17/17 | 86 ID không trộn nhãn, TP/FP/TN/FN = 17/23/46/0 | Recall episode bằng 1,000 theo quy tắc đã nêu | Phát hiện episode hoàn hảo hoặc sẵn sàng triển khai |
| Không FP trên polling ổn định | 0/444 cửa sổ và 0/37 benign chunk | Lỗi tập trung ở warm-up trong OOD2 | FPR bằng 0 cho mọi vận hành OPC UA |
| Tái lập model | Dự đoán model lưu khớp legacy | Tái lập suy luận trên OOD2/testclean | Tái lập bit-for-bit quá trình huấn luyện/CV |

**Nhận xét được bằng chứng hỗ trợ.** Đóng góp khoa học rõ nhất của nhánh OPC UA
không phải một điểm F1 đơn lẻ, mà là chuỗi kiểm chứng có truy vết: hiệu chỉnh
nhãn ở biên episode, chia nhóm chống lẫn cửa sổ cùng episode, kiểm tra chuyển
phiên, phân rã lỗi theo trạng thái phiên, ablation nhóm đặc trưng và đối chiếu
đến dự đoán từng cửa sổ. Chuỗi này cho phép chỉ ra đồng thời phần mô hình làm
tốt và phần chưa tổng quát hóa, đặc biệt là cảnh báo giả warm-up và phân loại
chi tiết giữa các hành vi gần nhau.

**Hạn chế của kết luận.** Chưa có capture frozen được thu sau khi khóa toàn bộ
pipeline; chưa có thay đổi có hệ thống về client, topology, PLC và
SecurityPolicy; chưa có đối chứng hoán đổi danh tính nguồn để kiểm tra leakage;
và chưa lưu bằng chứng số gói attacker theo cửa sổ. Ngoài ra, precision episode
phụ thuộc cách định nghĩa benign chunk. Các hạn chế này phải được giữ trong kết
luận thay vì diễn giải kết quả âm tính thành bằng chứng về khả năng tổng quát.

**Hướng kiểm chứng tiếp theo.** Cần khóa dependency bằng môi trường có phiên bản
cụ thể; niêm phong model và ngưỡng trước khi thu capture mới; bổ sung nhiều
client benign, attacker host, PLC và SecurityPolicy; lưu packet evidence theo
cửa sổ; đánh giá theo host/topology chưa thấy; và xây dựng đặc trưng trạng thái
phiên để nhận diện warm-up mà không dùng nhãn ground truth.

**Artifact nguồn cần gắn với bảng:**

- `experiments/opcua_research_v2/scientific_verification.json`;
- `experiments/opcua_research_v2/NUMBER_ARTIFACT_MATRIX.md`;
- toàn bộ các artifact con trong `label_audit/`, `feature_ablation/` và
  `warmup_ood/`.
